/*
 * comms_process.h
 *
 *  Created on: 3 ene. 2018
 */

#ifndef COMMS_PROCESS_H_
#define COMMS_PROCESS_H_

void comms_process(void);

#endif /* COMMS_PROCESS_H_ */
