/*
 * pga.h
 *
 *  Created on: 2 nov. 2017
 */

#ifndef PGA_H_
#define PGA_H_

#define WIPERB 		0x1

void set_gain(uint8_t gain);

#endif /* PGA_H_ */
